function d3_this() {
  return this;
}
