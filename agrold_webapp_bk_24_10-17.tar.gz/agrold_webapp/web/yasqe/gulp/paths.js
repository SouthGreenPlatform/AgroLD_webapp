module.exports =  {
	style: ['src/scss/scoped.scss', 'src/scss/global.scss'],
	bundleDir: "dist",
	bundleName: "yasqe",
	docDir: "doc"
};