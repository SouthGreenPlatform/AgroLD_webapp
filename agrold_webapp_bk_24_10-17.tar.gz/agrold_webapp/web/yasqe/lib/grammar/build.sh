#!/bin/bash
swipl  -s util/gen_sparql11.pl -t go
